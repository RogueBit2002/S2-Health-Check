source clean.sql;

source populate/populate_table_manager.sql;
source populate/populate_table_health_check.sql;