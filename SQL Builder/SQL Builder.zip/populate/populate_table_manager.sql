USE `rockstars_health_check`;

INSERT INTO `manager`(`email`, `password`) VALUES
	("laurens@kruis.name", "43951a7a2aa519b28b074c6a64065004bf12c8b2acd62a4d02870a505ddc0bc8");