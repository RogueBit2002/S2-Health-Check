USE `rockstars_health_check`;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE `manager`;
TRUNCATE `health_check`;

SET FOREIGN_KEY_CHECKS = 1;